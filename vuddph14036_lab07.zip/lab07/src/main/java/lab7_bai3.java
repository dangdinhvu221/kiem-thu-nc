import org.testng.annotations.Test;

public class lab7_bai3 {
    @Test(groups = "myGroup")
    public void d1() {

    }

    @Test
    public void d2() {

    }

}
