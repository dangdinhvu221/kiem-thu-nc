import org.testng.Assert;
import org.testng.annotations.Test;

public class lab7_bai2 {
    @Test
    public void class1() {

    }

    @Test
    public void class2() {

    }

    @Test
    public void class3() {

    }

    @Test
    public void class4() {
        Assert.assertTrue(false);
    }
}
