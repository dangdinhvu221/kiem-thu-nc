import org.testng.Reporter;
import org.testng.annotations.Test;

public class lab7_bai4 {
    @Test
    public void e1() {

    }

    @Test
    public void e2() {
        Reporter.log("Method name is e2");
    }

}
